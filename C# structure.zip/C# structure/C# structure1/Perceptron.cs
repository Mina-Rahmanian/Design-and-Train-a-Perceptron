using System;
using System.Collections.Generic;
using System.Linq;

namespace ArtificialNeuralNetwork
{
   public class Perceptron
   {
      // random number generator
      private Random m_rnd;

      // for each category, there are specific weighting factors
      private Dictionary<string, double[]> m_weightFactors = new Dictionary<string, double[]>();

      // the bios value by default is 1.0.
      private double m_bios = 1.0;

      // the learning rate for modifying the weighting factors by default is set to 0.25
      private double m_learningRate = 0.25;

      // for each category the required data (length and width) are stored here.
      private List<double[]> m_dataSet;

      // the error tolerance to exit the training (default to 0.1 %)
      private double m_errorTol;

      // maximum of repeatition on training (default to 500)
      private int m_maximumRepeatNo;

      // List of all unique categories
      private List<string> m_categories;

      // number of weighting factors
      private int m_nWeightingFactors;

      public Perceptron(List<double[]> dataSet, List<string> categories, double bios = 1.0, double learningRate = 0.1,
         double errorTol = 0.001, int maximumRepeatNumber = 500)
      {
         m_categories = categories;
         m_bios = bios;
         m_learningRate = learningRate;
         m_dataSet = dataSet;
         m_errorTol = errorTol;
         m_maximumRepeatNo = maximumRepeatNumber;
         m_nWeightingFactors = dataSet.First().Length - categories.Count + 1;
         foreach (var category in categories)
         {
            m_weightFactors.Add(category, new double[m_nWeightingFactors]);
         }

      }

      /// <summary>
      /// Train the model
      /// </summary>
      /// <returns></returns>
      public void GetTrained()
      {
         Dictionary<string, double[]> bestWeightingFactors = new Dictionary<string, double[]>();

         foreach (var category in m_categories)
         {
            bestWeightingFactors.Add(category, new double[m_nWeightingFactors]);
            m_rnd = new Random(DateTime.Now.Second);

            for (int iFactor = 0; iFactor < m_nWeightingFactors; iFactor++)
            {
               var rndValue = m_rnd.NextDouble();
               m_weightFactors[category][iFactor] = rndValue; // randomly assigned the weighting factors
               bestWeightingFactors[category][iFactor] = rndValue; // this local variable will keep track of the best weighting factors required by Pocket algorithm.
            }
         }

         double error = 1.0;
         double leastError = 1.0;
         int nCounter = 0;

         while (error > m_errorTol && nCounter < m_maximumRepeatNo) // exist the loop if the error is less that tol or maximum number of repetition is reached
         {
            int nError = 0;
            nCounter++;
            int nData = m_dataSet.Count;

            // go through the lest of data in a randomly selected index (i.e. pick data rows in random order)

            // create a list of int from 0 to nData.
            List<int> indexes = new List<int>(nData);
            for (int iData = 0; iData < nData; iData++)
            {
               indexes.Add(iData);
            }


            for (int iData = 0; iData < nData; iData++)
            {
               // pick random index
               m_rnd = new Random(nCounter * nError); // seed different number to random generator get better random number distribution at different execution.
               int idx = m_rnd.Next(0, indexes.Count);

               // get the number associate with that random index
               int rndIndex = indexes[idx];

               // take the associated row
               var rowData = m_dataSet[rndIndex];
               double sepalLength = rowData[0];
               double sepalWidth = rowData[1];
               double petalLength = rowData[2];
               double petalWidth = rowData[3];

               // remove the chosen index to avoiding repeating the same index.
               indexes.Remove(rndIndex);

               for (int iCategory = 0; iCategory < m_categories.Count; iCategory++)
               {
                  var category = m_categories[iCategory];
                  var weightFactors = m_weightFactors[category];

                  // evaluate based on current trained weighting factor
                  var calculated = Evaluate(sepalLength, sepalWidth, petalLength, petalWidth, weightFactors);

                  // get the target value
                  var target = m_dataSet[rndIndex][4 + iCategory];

                  // compare the calculated and target values
                  var diff = target - calculated;

                  if (Math.Abs(diff) > double.Epsilon) // correct the weighting factors if the evaluation failed.
                  {
                     nError++;
                     for (int iFactor = 0, nFactors = weightFactors.Length; iFactor < nFactors; iFactor++)
                     {
                        var value = iFactor == 0 ? m_bios : m_dataSet[rndIndex][iFactor - 1];
                        weightFactors[iFactor] += m_learningRate * diff * value;
                     }
                  }
               }
            }

            // error calculation
            error = (double) nError / m_dataSet.Count;
            if (error < leastError)
            {
               foreach (var category in m_categories)
               {
                  // keep track of best results so far. (Pocket algorithm)
                  for (int iFactor = 0; iFactor < m_nWeightingFactors; iFactor++)
                  {
                     bestWeightingFactors[category][iFactor] = m_weightFactors[category][iFactor];
                  }
               }

               // keep the least error so far.
               leastError = error;
            }
         }
            Console.WriteLine("Error of Training:" + leastError *100 + "%");
         foreach (var category in m_categories)
         {
            var weightFactors = bestWeightingFactors[category];
            m_weightFactors[category] = weightFactors; // store the best weighting factors of each category to be used in prediction process.
         }
      }


      // evaluate based on given length and width and weighting factors
      private double Evaluate(double sLength, double sWidth, double pLength, double pWidth, double[] weightFactors)
      {
         double sum = weightFactors[0] * m_bios;

         sum += sLength * weightFactors[1];
         sum += sWidth * weightFactors[2];
         sum += pLength * weightFactors[3];
         sum += pWidth * weightFactors[4];

         if (sum > 0.0)
         {
            return 1.0;
         }
         else
         {
            return 0.0;
         }
      }

      /// <summary>
      /// Guess the category after training
      /// </summary>
      /// <param name="petalLength"></param>
      /// <param name="petalWidth"></param>
      /// <returns></returns>
      public string GuessCategory(double sepalLength, double sepalWidth, double petalLength, double petalWidth)
      {
         string guessedClass = "NOT Found!";
         foreach (var category in m_categories)
         {
            if (Evaluate(sepalLength, sepalWidth, petalLength, petalWidth, m_weightFactors[category]) > 0.0)
            {
               guessedClass = category;
               break;
            }
         }

         return guessedClass;
      }
   }
}
